// 숫자라서 숫자 - x
// 숫자로서 의미가 있으면 숫자
// 평균내고, 최대값 찾고, ...
public class VMain2 {
	public static void main(String[] args) {
		String name = "플립3";
		int price = 0;
		String no = "010-3154-4435";
		double size = 3.5;
		boolean end = true; 
		
		System.out.println(name);
		System.out.printf("%d원\n", price);
		System.out.printf("번호 : %s\n", no);
		System.out.printf("%.2f인치\n", size);
		System.out.println(end);
	}
}




