package com.kwon.dec132oop.hero;

public class Ironman implements Hero {
	@Override
	public void attack() {
		System.out.println("빔 발사");
	}
}
