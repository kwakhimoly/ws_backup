
//쓰면 안되는 구역
public class PrintMain {
//아직 안 배운 구역
	public static void main(String[] args) {
		// main 아래는 자동 실행
		
		System.out.println("곽하영");
		// 콘솔 창에 뭐 출력하고 엔터까지(ln=line)
		
		System.out.print("집에 가고 싶다");
		// ln이 빠져서 줄 안 바뀌고 바로 이어서 출력됨
		
		System.out.println(" 솔이 보고 싶다");
		System.out.printf("%.3f", 3.14);
		// f=format(형식), 콘솔 창에 형식을 지정해서 출력
		//ex) 소숫점 두자리 수를 세자리까지 출력하도록 지정 3.14 -> 3.140
	}
//못쓰고 있는 구역(수동으로 실행)
}
//자바측에서 못 쓰게 해놓은 구역
