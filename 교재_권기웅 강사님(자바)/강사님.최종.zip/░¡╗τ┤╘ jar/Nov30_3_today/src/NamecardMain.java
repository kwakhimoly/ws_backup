// Export -> Runnable JAR File
// 메모장에 java -jar 파일명
//	 => ~~~.bat로 저장

public class NamecardMain {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("*****");
		System.out.println("* 권기웅 *");
		System.out.println("*****");
		System.out.println("* 집:\t분당 *");
		System.out.println("* 전화:\t010-3154-4435 *");
		System.out.println("*****");
		
		Thread.sleep(10000);
	}
}




