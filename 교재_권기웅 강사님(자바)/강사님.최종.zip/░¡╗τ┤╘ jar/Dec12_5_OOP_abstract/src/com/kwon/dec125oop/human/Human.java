package com.kwon.dec125oop.human;

// 클래스
//		추상메소드 - x
// 추상클래스 : 객체 못만드...
//		추상메소드도 됨
// 인터페이스 : 객체 못만들겠...
//		멤버변수 - x
//		멤버상수 - o
//		메소드 - x
//		추상메소드 - o
public interface Human {
	// private int a;
	public static final int B = 10;
//	public void c() {
//		
//	}
	public abstract void eat();
}



