
public class PrintMain3 {
	public static void main(String[] args) {
		System.out.printf("%d호선\r\n", 2);
		System.out.printf("%02d호선\n", 7);
		System.out.printf("시력: %.2f\n", 0.728 );
		System.out.printf("나: %s\n", "압살롬" );
		System.out.printf("습도: %d%%", 15 );
//		System.out.printf("형식", 데이터);
	}
}
