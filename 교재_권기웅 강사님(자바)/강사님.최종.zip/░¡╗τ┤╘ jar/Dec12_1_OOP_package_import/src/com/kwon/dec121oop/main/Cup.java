package com.kwon.dec121oop.main;

public class Cup {

}
