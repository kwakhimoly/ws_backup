
public class PrintMain2 {
	public static void main(String[] args) {
		System.out.println("곽\r\n하영");
		System.out.println("집:\t서울");
		System.out.println("학원:\t가산\b\b");
		System.out.println("이것저것 \\보장하라");
		System.out.println("아무거나 \"규탄한다\"");
	}
}
