
public class ExerciseMain {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("*********************************\r\n*곽하영\t\t\t\t*");
		System.out.println("*집:\t\t서울\t\t*\r\n*학원:\t\t가산\t\t*");
		System.out.print("*대중교통:");
		System.out.printf("%s호선", "\t2,7");
		System.out.print("\t\t*\r\n");
		System.out.print("*생일:\t\t");
		System.out.printf("%d월", 3);
		System.out.print("\t\t*\r\n*********************************");
		
//조금이라도 덜 쓰려고 한 경우 -> 근데 굳이 그럴 필요 없음
		
		System.out.println("\r\n");
		System.out.println("*********************************");
		System.out.println("*곽하영\t\t\t\t*");
		System.out.println("*집:\t\t서울\t\t*");
		System.out.println("*학원:\t\t가산\t\t*");
		System.out.print("*대중교통:");
		System.out.printf("%s호선", "\t2,7");
		System.out.print("\t\t*\r\n");
		System.out.print("*생일:\t\t");
		System.out.printf("%d일", 15);
		System.out.print("\t\t*\r\n");
		System.out.println("*********************************");
		

			Thread.sleep(10000);

		}
	}


