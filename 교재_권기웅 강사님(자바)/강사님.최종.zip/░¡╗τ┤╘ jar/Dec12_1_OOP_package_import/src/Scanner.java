
public class Scanner extends Product {

	public Scanner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Scanner(String name, int price) {
		super(name, price);
		// TODO Auto-generated constructor stub
	}
	
}
