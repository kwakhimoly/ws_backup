package com.kwon.dec125oop.flyer;

public interface Flyer {
	public abstract void fly();
}
