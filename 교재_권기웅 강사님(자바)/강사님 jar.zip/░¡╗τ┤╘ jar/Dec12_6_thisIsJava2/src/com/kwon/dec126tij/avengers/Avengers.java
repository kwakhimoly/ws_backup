package com.kwon.dec126tij.avengers;

public interface Avengers {
	public abstract void throwPunch();
}
