// 비만도 검사
// OOP의 컨셉 : 실생활
// OOD
//		병원에 가서 비만도 검사하는 씬을 떠올리시라
//		누구누구 나옵니까(엑스트라 빼고)
//			의사, 손님
public class OMain3 {
	public static void main(String[] args) {
		Doctor d = new Doctor();
		d.start();
	}
}
