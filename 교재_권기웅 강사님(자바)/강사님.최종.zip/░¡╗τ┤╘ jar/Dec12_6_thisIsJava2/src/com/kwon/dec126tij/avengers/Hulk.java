package com.kwon.dec126tij.avengers;

public class Hulk implements Avengers{

	@Override
	public void throwPunch() {
		System.out.println("퍽");
	}

}
