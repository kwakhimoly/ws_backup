package com.kwon.dec125oop.avengers;

public class Spiderman extends Avengers {

	@Override
	public void attack() {
		System.out.println("거미줄 발사");
	}

}
