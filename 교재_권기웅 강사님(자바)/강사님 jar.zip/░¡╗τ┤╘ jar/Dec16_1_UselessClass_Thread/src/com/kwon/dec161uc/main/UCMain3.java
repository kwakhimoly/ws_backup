package com.kwon.dec161uc.main;

import com.kwon.dec161uc.human.Human;

public class UCMain3 {
	public static void main(String[] args) {
		Human h = new Human();
		h.introduce();
	}
}
