// 변수 언제 만드나? : 데이터 임시 저장
// 객체 언제 만드나? : 데이터 임시 저장(좀 실생활스럽게)
public class UnitConverter {
	public static void toInch(double cm) {
		System.out.println(cm * 0.393701);
	}
}

