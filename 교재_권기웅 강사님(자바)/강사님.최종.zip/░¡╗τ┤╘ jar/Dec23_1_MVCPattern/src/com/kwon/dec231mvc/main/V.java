package com.kwon.dec231mvc.main;

import java.util.Scanner;

// front-end
// View - 디자이너
//		사용자에게 보여지는 영역
//		입력받고, 결과 출력하고
public class V {
	public static int getXY() {
		Scanner k = new Scanner(System.in);
		System.out.print("x : ");
		int x = k.nextInt();
		return x;
	}
	
	public static void print(String r) {
		System.out.println(r);
	}
}


