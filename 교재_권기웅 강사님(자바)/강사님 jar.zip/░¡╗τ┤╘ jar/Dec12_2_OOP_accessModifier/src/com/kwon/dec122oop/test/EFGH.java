package com.kwon.dec122oop.test;

// Test, EFGH의 관계 : 같은 패키지
public class EFGH {
	public void gogo() {
		Test t = new Test();
		t.a = 10;
		t.b = 20;
		t.c = 30;
		t.d = 40;
	}
}
