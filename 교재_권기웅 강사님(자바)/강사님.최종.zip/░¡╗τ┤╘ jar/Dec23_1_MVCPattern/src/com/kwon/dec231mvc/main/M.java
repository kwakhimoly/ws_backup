package com.kwon.dec231mvc.main;
// back-end
// Model - 개발자 + 고객
//		비즈니스 로직
//		실제 계산하는
public class M {
	public static String judge(int x) {
		return (x % 2 == 0) ? "짝" : "홀";
	}
}


