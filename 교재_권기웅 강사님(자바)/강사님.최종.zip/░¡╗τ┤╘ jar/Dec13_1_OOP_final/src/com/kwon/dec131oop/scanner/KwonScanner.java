package com.kwon.dec131oop.scanner;

// 정수 입력받는데, 짝수만
public class KwonScanner extends Scanner{

}
