
public class Car {
	String name;
	int price;
	
	public void print() {
		System.out.println(name);
		System.out.println(price);
	}
}
