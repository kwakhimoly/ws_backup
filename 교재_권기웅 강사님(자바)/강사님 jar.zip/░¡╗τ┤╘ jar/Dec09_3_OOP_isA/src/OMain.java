
public class OMain {
	public static void main(String[] args) {
		
		Taxi t = new Taxi();
		t.name = "소나타";
		t.price = 2500;
		t.pay = 3800;
		t.print();
	}
}
