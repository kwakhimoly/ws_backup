package com.kwon.dec122oop.test;

public class Test {
	public int a;
	protected int b;
	int c;
	private int d;
}
