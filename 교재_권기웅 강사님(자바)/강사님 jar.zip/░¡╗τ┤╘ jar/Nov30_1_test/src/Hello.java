// 이 줄은 전체 다 자바 소스로 안쳐줌
/* 여기만 */
/*
 * 여
 * 러
 * 줄
 */

// ctrl + / : 
// ctrl + shift + / : 

// alt + 화살표 위/아래 : 
// ctrl + alt + 화살표 위/아래 :
// ctrl + d :

// ctrl + shift + f : 

// ctrl + shift + +/-(numpad) :

// ctrl + f11 : 
// ctrl + spaceBar

// / : slash
// \ : back-slash
// | : pipe(bar)
// : : colon
// ; : semi-colon

// 컴 무리없이 쓰시냐 : yes

/**
 * 주석
 * 
 * @author user
 *
 */
public class Hello {
	public static void main(String[] args) {
		System.out.println("밥");
	}
}
