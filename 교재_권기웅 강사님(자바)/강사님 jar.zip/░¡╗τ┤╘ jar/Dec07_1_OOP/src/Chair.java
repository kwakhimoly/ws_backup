// 의자라는 자료형 만드는 느낌
// 객체, instance : 붕어빵
// 클래스 : 붕어빵틀(도장)
public class Chair {
	String name;
	String maker;
	int price;
	boolean comfort;

	public void printInfo() {
		System.out.println(name);
		System.out.println(maker);
		System.out.println(price);
		System.out.println(comfort);
	}
}
