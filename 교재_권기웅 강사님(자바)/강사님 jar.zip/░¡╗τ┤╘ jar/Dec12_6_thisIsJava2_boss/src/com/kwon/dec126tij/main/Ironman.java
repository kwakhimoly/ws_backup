package com.kwon.dec126tij.main;

public class Ironman {
	public void attack() {
		System.out.println("빔 발사");
	}
}
