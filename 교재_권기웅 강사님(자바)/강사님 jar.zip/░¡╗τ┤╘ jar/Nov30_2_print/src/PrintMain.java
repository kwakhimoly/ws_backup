// 프로그래밍 : 번역
// 	한국어 -번역(개발)-> Java -번역(compile)-> 기계어 -실행->

// 사과가 왜 영어로 apple
// 이해가 안된다-x
// 왜 - x
// 언제 - o
// 외우지 마시길, 자꾸 반복하다가 외워지면 땡큐

// shift + enter
// end누르고 엔터
public class PrintMain {
	public static void main(String[] args) {
		// 잘 모르겠는데 여기다 써야 자동 실행되니까...
		
		// 실전 : 중간결과 테스트2
		// 		줄 바뀌는게 보기 편하지 않나
		
		// 콘솔창에 뭐 출력하고나서 줄바꿈
		System.out.println("ㅋㅋㅋㅋ");
		System.out.println("권기웅");
		// 콘솔창에 뭐 출력
		System.out.print("하필 추운날");
		// 콘솔창에 형식 지정해서 출력
		System.out.printf("%.3f", 3.14);
		System.out.println("원장님 걸리면 가만 안둔다");
	}
}


