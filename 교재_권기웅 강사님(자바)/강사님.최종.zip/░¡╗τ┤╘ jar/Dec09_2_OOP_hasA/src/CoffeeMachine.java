
public class CoffeeMachine {
	String name;
	int price;
	
	public CoffeeMachine() {
		// TODO Auto-generated constructor stub
	}

	public CoffeeMachine(String name, int price) {
		super();
		this.name = name;
		this.price = price;
	}
	
	public void pick() {
		System.out.println("드르륵");
	}
	
}



