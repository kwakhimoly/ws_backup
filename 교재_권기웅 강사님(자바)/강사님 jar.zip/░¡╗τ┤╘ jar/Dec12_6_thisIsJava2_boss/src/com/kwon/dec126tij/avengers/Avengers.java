package com.kwon.dec126tij.avengers;

// interface : 의사소통
public interface Avengers {
	public abstract void throwPunch();
}
