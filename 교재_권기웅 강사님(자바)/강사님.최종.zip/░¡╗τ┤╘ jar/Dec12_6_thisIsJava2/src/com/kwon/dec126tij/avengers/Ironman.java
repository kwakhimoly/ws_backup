package com.kwon.dec126tij.avengers;

public class Ironman {
	public void attack() {
		System.out.println("빔 발사");
	}
}
