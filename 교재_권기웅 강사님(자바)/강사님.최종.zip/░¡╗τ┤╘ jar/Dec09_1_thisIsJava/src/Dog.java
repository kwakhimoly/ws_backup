// Dec09_1_ThisIsJava : 신입
//		Dog.java : 신입이 작업한거
//		+ 설명서

// Dec09_2_OOP_HasA : 사수
//		소스를 못보니까
//		신입이 어떻게 해놨을지 아나...
//		eclipse가 엄청 도와주니까 크게 문제는 아닌데...
//		문화가 있어서 크게 문제는 아닌데...
//		그래도...

// Project - Generate Javadoc

// java : oracle
// 한빛미디어

// 책 : 한빛미디어
//		2021/01/01
//		2022/12/09

/**
 * test
 * @author hahaha
 *
 */
public class Dog {
	String name;
	int age;

	public Dog() {
		// TODO Auto-generated constructor stub
	}

	public Dog(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	/**
	 * abc
	 * @param cmaaa
	 * @return asdsd incha
	 */
	public double toInch(double cm) {
		return cm * 0.456464;
	}
	
	/**
	 * abcd
	 */
	public void show() {
		System.out.println(name);
		System.out.println(age);
	}
}



