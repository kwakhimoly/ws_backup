package com.kwon.dec132oop.hero;

public class Hulk implements Hero{

	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
	}

}
