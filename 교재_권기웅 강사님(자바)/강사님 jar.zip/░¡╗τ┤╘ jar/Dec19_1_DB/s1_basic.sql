-- DBA쪽 기능은 안됨
-- sqlplus라는 프로그램의 명령어는 안됨
desc dec19_product2;

-- 한 줄 실행 : 커서갖다놓고 -> alt + s
select * from dec19_product2;

-- 여러 줄 실행 : 블록지정 -> alt + x
create table dec19_product2(
	s_name varchar2(1),
	s_price number
);

