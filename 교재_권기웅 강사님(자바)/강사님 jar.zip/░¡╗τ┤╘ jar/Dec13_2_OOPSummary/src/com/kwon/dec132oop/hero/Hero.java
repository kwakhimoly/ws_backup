package com.kwon.dec132oop.hero;

public interface Hero {
	public abstract void attack();
}
